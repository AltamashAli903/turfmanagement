import { MapPin, Star } from "lucide-react";
import Button from "./Button";

export default function TurfCard({ turf }) {
  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-lg transition duration-300 hover:-translate-y-2 hover:shadow-2xl">

      <img
        src={turf.image}
        alt={turf.name}
        className="h-56 w-full object-cover"
      />

      <div className="p-5">

        <div className="flex items-center justify-between">

          <h3 className="text-xl font-bold text-slate-900">
            {turf.name}
          </h3>

          <span className="flex items-center gap-1 rounded-full bg-yellow-100 px-2 py-1 text-sm font-semibold text-yellow-700">
            <Star size={14} fill="currentColor" />
            {turf.rating}
          </span>

        </div>

        <div className="mt-3 flex items-center gap-2 text-slate-500">
          <MapPin size={16} />
          {turf.location}
        </div>

        <div className="mt-4 flex items-center justify-between">

          <div>

            <p className="text-slate-500 text-sm">
              Starting From
            </p>

            <h4 className="text-xl font-bold text-green-600">
              ₹{turf.price}/hr
            </h4>

          </div>

          <Button>
            Book Now
          </Button>

        </div>

      </div>

    </div>
  );
}