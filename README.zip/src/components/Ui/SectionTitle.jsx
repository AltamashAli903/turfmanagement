export default function SectionTitle({
  badge,
  title,
  subtitle,
  center = true,
}) {
  return (
    <div
      className={`mb-12 ${
        center ? "text-center" : "text-left"
      }`}
    >
      {badge && (
        <span className="inline-block rounded-full bg-green-100 px-4 py-1 text-sm font-medium text-green-700">
          {badge}
        </span>
      )}

      <h2 className="mt-4 text-4xl font-bold text-slate-900">
        {title}
      </h2>

      {subtitle && (
        <p className="mx-auto mt-4 max-w-2xl text-slate-500">
          {subtitle}
        </p>
      )}
    </div>
  );
}